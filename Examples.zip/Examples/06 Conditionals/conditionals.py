#!/usr/bin/python3

def main():
    print("This is the conditionals.py file.")

if __name__ == "__main__": main()
