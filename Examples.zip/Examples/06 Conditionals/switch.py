#!/usr/bin/python3

def main():
    print('this is the switch.py file')

if __name__ == "__main__": main()
