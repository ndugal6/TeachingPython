#!/usr/bin/python3


def main():
    print('This is the containers.py file.')

if __name__ == "__main__": main()
