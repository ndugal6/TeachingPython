#!/usr/bin/python3


import sqlite3

def main():
    print('This is the databases.py file')

if __name__ == "__main__": main()
