#!/usr/bin/python3


def main():
    o = range(25)
    for i in o: print(i, end = ' ')

if __name__ == "__main__": main()
