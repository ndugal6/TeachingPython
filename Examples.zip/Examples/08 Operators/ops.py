#!/usr/bin/python3


def main():
    print("This is the ops.py file.")

if __name__ == "__main__": main()
