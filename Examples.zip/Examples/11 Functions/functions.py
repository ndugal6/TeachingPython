#!/usr/bin/python3

def main():
    testfunc()

def testfunc():
    print('This is a test function')

if __name__ == "__main__": main()
