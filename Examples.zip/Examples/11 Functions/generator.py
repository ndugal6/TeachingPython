#!/usr/bin/python3


def main():
    print("This is the functions.py file.")
    for i in range(25):
        print(i, end = ' ')

if __name__ == "__main__": main()
