#!/usr/bin/python3


fh = open('xlines.txt')
for line in fh.readlines():
    print(line)

