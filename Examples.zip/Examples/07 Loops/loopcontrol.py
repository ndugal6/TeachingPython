#!/usr/bin/python3

def main():
    s = 'this is a string'
    for c in s:
        print(c, end='')

if __name__ == "__main__": main()
